<img alt="UCU" src="https://www.ucu.edu.uy/plantillas/images/logo_ucu.svg"
width="150"/>

# Universidad Católica del Uruguay

## Facultad de Ingeniería y Tecnologías

### Programación II

# Clase `Person` encapsulada

Agrega la clase `Person` con las responsabilidades de conocer el nombre `Name` y
la cédula `Id` de forma que sólo acepte nombres y cédulas válidas:

- El nombre es válido si no está en blanco.
- La cédula es válida si es correcto el dígito verificador.

Usen el código provisto en el adjunto como punto de partida. El código incluye
líneas que crean personas con información válida y el código para verificar si
una cédula es válida calculando el dígito verificador.

No incluye el código de la clase Person, que deberán programar ustedes a partir
del [ejercicio](https://github.com/ucudal/PII_Identificar_partes_de_objeto) de
identificar las partes de un objeto.
